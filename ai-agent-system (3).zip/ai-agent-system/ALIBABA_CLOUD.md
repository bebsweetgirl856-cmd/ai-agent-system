# Deploying on Alibaba Cloud (ECS)

This walks through the "get a server" and "point a domain" steps specific
to Alibaba Cloud. Once the server is up, everything else is identical to
the generic cloud steps in `README.md` (Docker + Caddy + the agent) - come
back to that file for steps 3 onward.

## 1. Create an ECS instance

1. Log into the [Alibaba Cloud console](https://ecs.console.aliyun.com/).
2. Go to **ECS → Instances → Create Instance**.
3. Choose:
   - **Region**: pick one close to you (affects latency, not functionality).
   - **Instance type**: a small burstable type is enough, e.g. `ecs.t6-c1m2.large`
     (2 vCPU / 4GB) or even a 1-2GB `ecs.t6-c1m1.large` - this agent is
     lightweight.
   - **Image**: **Ubuntu 22.04 64-bit** (or 24.04 if offered).
   - **Storage**: default 40GB system disk is plenty.
   - **Network**: default VPC is fine.
   - **Public IP**: make sure "Assign Public IP" is checked, with enough
     bandwidth (1-5 Mbps is fine for a personal dashboard).
   - **Security group**: create or select one that allows inbound on
     **22 (SSH), 80 (HTTP), 443 (HTTPS)** - see step 2 if you need to add
     these after creation.
   - **Login credentials**: set a root/admin password, or upload an SSH key
     pair (recommended - Alibaba can generate one for you to download).
4. Confirm and launch. Note the instance's **public IP address** once it's
   running (Instances list → your instance).

## 2. Open the required ports (Security Group)

If you didn't already allow them at creation:
1. **ECS console → Network & Security → Security Groups**.
2. Select the security group attached to your instance → **Add Rules**.
3. Add inbound rules for:
   - Port `22` (SSH) - restrict "Authorization Object" to your own IP if
     you can, for safety.
   - Port `80` (HTTP) - `0.0.0.0/0` (needed for Let's Encrypt's HTTPS
     verification).
   - Port `443` (HTTPS) - `0.0.0.0/0`.

## 3. Point your domain at the instance

You need a real domain pointed at the server's public IP for Caddy to get
you free HTTPS automatically.

- **If your domain is already registered with Alibaba Cloud** (or you
  transfer/host DNS there): go to **Alibaba Cloud DNS (云解析 DNS) console**
  → your domain → **Add Record** → type `A`, host record `agent` (for
  `agent.yourdomain.com`), value = your ECS instance's public IP, TTL
  10 min. Save and wait a few minutes to propagate.
- **If your domain is registered elsewhere** (GoDaddy, Namecheap, etc.):
  just add the same `A` record in that registrar's DNS panel instead -
  Alibaba Cloud doesn't need to be involved for DNS.

Verify it resolves before continuing:
```bash
ping agent.yourdomain.com
# should show your ECS instance's public IP
```

## 4. SSH into the instance

```bash
ssh root@<your-ecs-public-ip>
```
(or `ssh -i your-key.pem root@<ip>` if you used an SSH key pair; Alibaba's
default Ubuntu images typically log in as `root`).

If this is a fresh instance, it's worth doing basic hardening first:
```bash
apt update && apt upgrade -y
# optional but recommended: create a non-root user
adduser deploy
usermod -aG sudo deploy
```

## 5. Continue with the standard Docker deployment

From here, follow **README.md → "Deploying to a cloud server"**, starting
at step 2 ("Install Docker on the server"). In short:

```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
# log out and back in

scp -r ai-agent-system your-user@<ecs-ip>:~/ai-agent-system
cd ai-agent-system
cp .env.example .env
nano .env   # fill in ANTHROPIC_API_KEY, DOMAIN, SESSION_SECRET, DASHBOARD_PASSWORD_HASH

docker compose up -d --build
```

Then open `https://agent.yourdomain.com` on your iPhone and log in.

## Alibaba-specific notes

- **Firewall**: Alibaba's Security Group rules (step 2 above) are the main
  gate - Ubuntu's own `ufw` firewall is usually inactive by default on
  these images, but double check with `sudo ufw status` and only enable it
  if you also open 22/80/443 there too (easy to lock yourself out
  otherwise).
- **Elastic IP**: if you stop/restart the instance and it loses its public
  IP, either bind an **Elastic IP (EIP)** to the instance (recommended for
  a service you want to keep the same DNS record working with), or update
  your DNS `A` record each time.
- **Billing**: pay-as-you-go ECS instances bill by the hour/second while
  running - stopping the instance (not just the Docker containers) avoids
  compute charges if you ever want to pause everything, though your data
  in the Docker volume only persists as long as the underlying disk isn't
  deleted.
