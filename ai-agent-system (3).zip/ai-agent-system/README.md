# Local AI Agent System (Claude-powered, runs 24/7 on your PC)

A self-contained AI agent with:
- Claude API as the brain, with a tool-use loop
- Extensible tools/actions (calculator, file read/write, web fetch, memory, datetime)
- Persistent memory + conversation history in SQLite
- Scheduled/automated tasks (interval or cron)
- A browser dashboard: chat, start/stop/restart, real-time logs, task manager, tool list
- Auto-restart on crash (watchdog) and auto-start on Windows boot (Windows Service via NSSM)

## Folder structure

```
ai-agent-system/
├── backend/
│   ├── main.py              # FastAPI app + REST/WebSocket endpoints
│   ├── agent.py              # Claude API tool-use loop
│   ├── scheduler.py          # APScheduler-based task runner
│   ├── database.py           # SQLite persistence (memory, history, tasks, logs)
│   ├── logger.py             # Real-time log broadcasting to the dashboard
│   ├── config.py             # Loads .env / settings
│   ├── watchdog.py           # Keeps the server alive 24/7, restarts on crash
│   ├── requirements.txt
│   ├── tools/                # <-- add new tools here
│   │   ├── base.py            # tool registry / decorator
│   │   ├── datetime_tool.py
│   │   ├── calculator_tool.py
│   │   ├── file_tool.py
│   │   ├── http_request_tool.py
│   │   └── memory_tool.py
│   └── static/                # dashboard frontend (plain HTML/CSS/JS)
│       ├── index.html
│       ├── style.css
│       └── app.js
├── install/
│   ├── setup.bat                      # one-time install
│   ├── start_agent.bat                # manual foreground start
│   ├── stop_agent.bat
│   └── install_windows_service.ps1    # installs as a real Windows Service
├── data/                    # created automatically: agent.db, logs, sandbox files
├── .env.example              # copy to .env and fill in your API key
└── README.md
```

## Step-by-step: install & run on Windows

### 1. Prerequisites
- **Python 3.11+** installed and on PATH. Check with `python --version` in Command Prompt.
  Get it from https://www.python.org/downloads/ (tick "Add Python to PATH" during install).
- An **Anthropic API key** from https://console.anthropic.com/settings/keys

### 2. Unzip the project
Unzip `ai-agent-system.zip` anywhere, e.g. `C:\ai-agent-system`.

### 3. One-time setup
Double-click **`install\setup.bat`**. It will:
- create a Python virtual environment in `venv\`
- install all dependencies
- create a `.env` file from the template

### 4. Add your API key
Open the newly created **`.env`** file (in the project root) with Notepad and set:
```
ANTHROPIC_API_KEY=sk-ant-...your real key...
```
Save the file.

### 5. Run it
For a quick test, double-click **`install\start_agent.bat`**. Keep the window open -
it launches the watchdog, which launches the dashboard server and auto-restarts it
if it ever crashes.

Then open your browser to:
```
http://127.0.0.1:8787
```
You'll see the dashboard: Chat / Scheduled Tasks / Live Logs / Tools tabs, plus
Start / Stop / Restart controls at the top.

Closing the console window stops the agent. For real 24/7 use, install it as a
Windows Service (next step) instead of leaving a console window open.

### 6. Run it 24/7 as a background Windows Service (auto-starts on boot)
This uses **NSSM** (Non-Sucking Service Manager), a small, well-known, free tool
for wrapping any program as a proper Windows service with auto-restart.

1. Download NSSM from https://nssm.cc/download and unzip it.
2. Copy `nssm.exe` (from the `win64` folder) into this project's `install\` folder.
3. Right-click **PowerShell** → **Run as Administrator**.
4. Run:
   ```powershell
   cd C:\ai-agent-system\install
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\install_windows_service.ps1
   ```
5. Done. The agent now:
   - runs invisibly in the background
   - starts automatically every time Windows boots (even before anyone logs in)
   - restarts itself automatically if the process crashes (NSSM) **and** the
     internal watchdog also backs off/retries if Claude API calls or the server
     itself throw repeated errors

Open `http://127.0.0.1:8787` any time - the dashboard is always running.

**Managing the service** (from an Administrator PowerShell/CMD):
```
nssm start   LocalAIAgent
nssm stop    LocalAIAgent
nssm restart LocalAIAgent
nssm remove  LocalAIAgent confirm     (uninstalls the service)
```

Service logs are also written to `data\service_stdout.log` / `service_stderr.log`,
and all agent activity is in `data\agent.log` and the dashboard's Live Logs tab.

### Alternative to NSSM: Windows Task Scheduler
If you'd rather not use NSSM, you can achieve auto-start-on-boot with Task
Scheduler instead:
1. Open **Task Scheduler** → **Create Task** (not "Basic Task").
2. **General tab**: Name it "Local AI Agent". Select "Run whether user is
   logged on or not". Check "Run with highest privileges".
3. **Triggers tab**: New → "At startup".
4. **Actions tab**: New → Program/script: `C:\ai-agent-system\venv\Scripts\python.exe`,
   Arguments: `watchdog.py`, Start in: `C:\ai-agent-system\backend`.
5. **Settings tab**: check "If the task fails, restart every" 1 minute, and
   uncheck "Stop the task if it runs longer than" (or set it very high) since
   this must run continuously.
6. Save (you'll be asked for your Windows password since it runs whether
   logged in or not).

This is less robust than NSSM (Task Scheduler doesn't watch the process as
tightly), but works if you'd rather avoid a third-party tool.

## Using the dashboard

- **Chat tab** - talk to the agent directly. It remembers conversation history
  (stored in SQLite) and can call any registered tool automatically.
- **Scheduled Tasks tab** - add a task with either:
  - "Every N minutes" → enter a number, e.g. `60` for hourly
  - "Cron expression" → e.g. `0 9 * * *` for every day at 9am
  Each task sends its prompt text to the agent on that schedule, and the
  result + last-run time show up on the task card.
- **Live Logs tab** - real-time stream of everything the agent does: chat
  turns, tool calls and their results, scheduled task runs, errors, and
  server start/stop events. Updates instantly via WebSocket.
- **Tools tab** - lists every tool currently available to the agent.
- **Start / Stop / Restart** (top right) - pauses/resumes the agent's ability
  to respond to chat and run scheduled tasks, without shutting down the
  dashboard server itself (so the UI is always reachable).

## Adding a new tool

1. Create `backend/tools/my_tool.py`:
   ```python
   from tools.base import tool

   @tool(
       name="my_tool",
       description="Explain clearly what this does and when Claude should use it.",
       input_schema={
           "type": "object",
           "properties": {"param": {"type": "string"}},
           "required": ["param"],
       },
   )
   def my_tool(param: str):
       return f"Result for {param}"
   ```
2. Register it in `backend/tools/__init__.py`:
   ```python
   from . import my_tool  # noqa: F401
   ```
3. Restart the agent (dashboard "Restart" button, or restart the service).
   It will show up in the Tools tab and Claude can call it immediately.

## Security notes

- Your API key lives only in `.env` (never committed to git - see `.gitignore`),
  and is loaded via environment variables through `config.py`.
- The dashboard binds to `127.0.0.1` by default (only reachable from your own
  PC). If you change `DASHBOARD_HOST` in `.env` to make it reachable on your
  network, also set `DASHBOARD_TOKEN` in `.env` and send it as the
  `X-Dashboard-Token` header on API requests - otherwise anyone on your
  network could chat as your agent or read its logs.
- The `write_file`/`read_file`/`list_files` tools are sandboxed to
  `data/sandbox/` only - the agent cannot read or write arbitrary files on
  your PC.

## Deploying to a cloud server (access from your iPhone anywhere)

This is the recommended setup once you want to reach your agent from your
phone over the internet, not just on your home network. It uses Docker so
it works the same on any Linux VPS (DigitalOcean, Linode, AWS Lightsail,
Hetzner, etc.) and adds:
- **A real login** (password, not just an open dashboard) - required, since
  the server is now internet-facing
- **Automatic HTTPS** via Caddy, so your iPhone connects over `https://`
- **"Add to Home Screen"** support so it behaves like a native app on iOS

```
CLOUD SERVER
┌───────────────────┐
│   YOUR AI AGENT    │   Docker container: agent (FastAPI + Claude API,
│  (Docker container)│   memory, tools, scheduler)
└─────────┬──────────┘
          │ reverse proxy (Caddy container, auto HTTPS)
          │
       Internet
          │
     📱 iPhone 16 (Safari, or "Add to Home Screen")
     Dashboard: Chat / Tasks / Logs
```

### 1. Get a server and a domain
- Spin up a small Ubuntu 22.04+ VPS (1 vCPU / 1-2GB RAM is plenty). Note its
  public IP.
  - **Using Alibaba Cloud?** See `ALIBABA_CLOUD.md` for provider-specific
    steps (creating the ECS instance, security group ports, DNS) - then
    come back here at step 2.
  - **Using Oracle Cloud?** See `ORACLE_CLOUD.md` for provider-specific
    steps (Always Free tier, creating the Compute instance, and Oracle's
    two-layer firewall) - then come back here at step 2.
- Point a domain (or subdomain, e.g. `agent.yourdomain.com`) at that IP with
  an **A record**. Caddy needs this for automatic HTTPS - without a real
  domain pointed at the server, it can't get a Let's Encrypt certificate.

### 2. Install Docker on the server
SSH into your server, then:
```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
# log out and back in for the group change to take effect
```

### 3. Copy the project to the server
From your own machine:
```bash
scp -r ai-agent-system your-user@your-server-ip:~/ai-agent-system
```
Or `git clone` it if you've pushed it to a repo (make sure `.env` is
excluded - it's already in `.gitignore`).

### 4. Configure `.env` for cloud use
On the server, inside `ai-agent-system`:
```bash
cp .env.example .env
nano .env
```
Set at minimum:
```
ANTHROPIC_API_KEY=sk-ant-...
DOMAIN=agent.yourdomain.com
SESSION_SECRET=<paste output of: python3 -c "import secrets; print(secrets.token_hex(32))">
```
Then generate your dashboard password hash. Easiest way (no local Python
needed - run it inside the container image itself):
```bash
docker run --rm -it -v "$PWD/backend:/app" -w /app python:3.12-slim \
  bash -c "pip install -q bcrypt && python gen_password.py"
```
Paste the printed `DASHBOARD_PASSWORD_HASH=...` line into `.env`.

### 5. Launch
```bash
docker compose up -d --build
```
That's it. Caddy automatically requests and renews the HTTPS certificate for
your domain the first time it starts (make sure ports 80 and 443 are open in
your server's firewall/security group).

Open on your iPhone:
```
https://agent.yourdomain.com
```
Log in with the password you set in step 4. On iOS Safari, tap **Share →
Add to Home Screen** to install it like an app (full-screen, no browser
chrome, works via the `manifest.json` already included).

### 6. Managing the cloud deployment
```bash
docker compose logs -f agent      # tail the agent's logs
docker compose restart agent      # restart just the agent
docker compose down               # stop everything
docker compose up -d --build      # rebuild & restart after you edit code
```
Both containers have `restart: unless-stopped`, so the whole stack survives
server reboots automatically - no extra Task Scheduler/NSSM step needed in
the cloud version (that's specific to the local-Windows path above).

Your data (SQLite DB, memory, sandbox files) lives in the `agent_data`
Docker volume, so it survives `docker compose down`/`up` and rebuilds. Back
it up with `docker run --rm -v ai-agent-system_agent_data:/data -v $PWD:/backup alpine tar czf /backup/agent-data-backup.tar.gz /data`.

### Security notes specific to the cloud deployment
- **Never** run this internet-facing without `DASHBOARD_PASSWORD_HASH` set -
  without it, `AUTH_ENABLED` is `false` and the dashboard (and your API
  key's usage) is wide open to anyone who finds the URL.
- Sessions are signed cookies (not stored server-side), valid for 30 days by
  default (`SESSION_MAX_AGE_SECONDS` in `.env`) - shorten this if you want
  more frequent re-logins.
- Only Caddy's ports (80/443) are exposed to the internet; the agent
  container itself is reachable only from inside the Docker network.

## Troubleshooting

- **"ANTHROPIC_API_KEY is not set" warning** → you haven't edited `.env`, or
  saved it in the wrong folder (it must sit next to `.env.example`, in the
  project root, not inside `backend/`).
- **Dashboard won't load** → check `data\agent.log` or the console window for
  errors; make sure nothing else is using port 8787 (change `DASHBOARD_PORT`
  in `.env` if needed).
- **Service won't start** → check `data\service_stderr.log`, and confirm
  `venv\Scripts\python.exe` exists (re-run `install\setup.bat` if not).
