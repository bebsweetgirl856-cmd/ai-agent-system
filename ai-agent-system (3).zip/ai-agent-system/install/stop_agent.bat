@echo off
REM Stops the agent if it's running as a background Windows Service (NSSM).
REM If you're running it in a console window instead, just close that window
REM or press CTRL+C in it.
nssm stop LocalAIAgent
echo If that failed with "service not found", you are probably running the
echo agent in a normal console window instead of as a service - just close
echo that window (or CTRL+C in it) to stop it.
pause
