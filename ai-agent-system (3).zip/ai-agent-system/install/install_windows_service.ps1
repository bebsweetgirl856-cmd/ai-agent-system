<#
Installs the AI Agent as a proper Windows Service using NSSM, so it:
  - starts automatically when Windows boots (even before login)
  - restarts automatically if it crashes
  - runs completely in the background (no console window)

PREREQUISITES:
  1. You've already run install\setup.bat successfully.
  2. Download NSSM from https://nssm.cc/download, unzip it, and either:
       a) put nssm.exe on your PATH, or
       b) place nssm.exe directly into this "install" folder.
  3. Run this script from an elevated (Administrator) PowerShell:
       Right-click PowerShell -> "Run as Administrator", then:
       cd path\to\ai-agent-system\install
       .\install_windows_service.ps1
#>

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$venvPython = Join-Path $root "venv\Scripts\python.exe"
$watchdog = Join-Path $root "backend\watchdog.py"
$backendDir = Join-Path $root "backend"
$serviceName = "LocalAIAgent"

# Find nssm.exe (local folder first, then PATH)
$nssmLocal = Join-Path $PSScriptRoot "nssm.exe"
if (Test-Path $nssmLocal) {
    $nssm = $nssmLocal
} else {
    $nssm = (Get-Command nssm.exe -ErrorAction SilentlyContinue).Source
}
if (-not $nssm) {
    Write-Host "ERROR: nssm.exe not found. Download it from https://nssm.cc/download" -ForegroundColor Red
    Write-Host "and place nssm.exe in this 'install' folder, then re-run this script." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $venvPython)) {
    Write-Host "ERROR: venv not found. Run install\setup.bat first." -ForegroundColor Red
    exit 1
}

Write-Host "Installing Windows service '$serviceName' using NSSM at $nssm ..."

& $nssm install $serviceName $venvPython $watchdog
& $nssm set $serviceName AppDirectory $backendDir
& $nssm set $serviceName DisplayName "Local AI Agent (Claude)"
& $nssm set $serviceName Description "24/7 personal AI agent with dashboard, tools, memory and scheduled tasks."
& $nssm set $serviceName Start SERVICE_AUTO_START
& $nssm set $serviceName AppStdout (Join-Path $root "data\service_stdout.log")
& $nssm set $serviceName AppStderr (Join-Path $root "data\service_stderr.log")
& $nssm set $serviceName AppRotateFiles 1
& $nssm set $serviceName AppExit Default Restart
& $nssm set $serviceName AppRestartDelay 5000

Write-Host ""
Write-Host "Service installed. Starting it now..." -ForegroundColor Green
& $nssm start $serviceName

Write-Host ""
Write-Host "============================================================"
Write-Host " Done! The agent now runs 24/7 in the background and will"
Write-Host " auto-start every time Windows boots."
Write-Host ""
Write-Host " Dashboard: http://127.0.0.1:8787"
Write-Host ""
Write-Host " Manage the service with:"
Write-Host "   nssm start   $serviceName"
Write-Host "   nssm stop    $serviceName"
Write-Host "   nssm restart $serviceName"
Write-Host "   nssm remove  $serviceName confirm   (to uninstall)"
Write-Host "============================================================"
