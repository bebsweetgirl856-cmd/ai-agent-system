@echo off
REM ============================================================
REM Starts the agent (via the watchdog, so it auto-restarts on
REM crash). Leave this window open, or use the NSSM service
REM instructions in README.md to run it invisibly in the
REM background and auto-start with Windows.
REM ============================================================
cd /d "%~dp0..\backend"
call ..\venv\Scripts\activate.bat
python watchdog.py
