@echo off
REM ============================================================
REM One-time setup: creates a virtual environment and installs
REM all dependencies. Run this once after unzipping the project.
REM ============================================================
cd /d "%~dp0.."

echo Creating virtual environment...
python -m venv venv

echo Installing dependencies...
call venv\Scripts\activate.bat
pip install --upgrade pip
pip install -r backend\requirements.txt

if not exist ".env" (
    echo Creating .env from template - EDIT THIS FILE and add your API key!
    copy .env.example .env
)

echo.
echo ============================================================
echo Setup complete!
echo 1. Open the ".env" file in this folder and paste your
echo    Anthropic API key into ANTHROPIC_API_KEY=
echo 2. Then run install\start_agent.bat to launch the dashboard.
echo ============================================================
pause
