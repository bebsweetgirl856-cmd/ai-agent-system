"""
Lightweight persistence layer on top of SQLite (no ORM - keeps this easy to
read and hack on). Handles:
  - conversation history (agent memory across restarts)
  - a generic key/value long-term memory store
  - scheduled task definitions
  - activity logs
"""
import sqlite3
import json
import threading
from datetime import datetime, timezone
from contextlib import contextmanager

from config import DB_PATH

_lock = threading.Lock()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def get_conn():
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        with _lock:
            yield conn
            conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL DEFAULT 'default',
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS memory (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                schedule_type TEXT NOT NULL,   -- 'interval' or 'cron'
                schedule_value TEXT NOT NULL,  -- e.g. minutes int, or cron string
                prompt TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                last_run TEXT,
                last_result TEXT,
                created_at TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                level TEXT NOT NULL,
                source TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()


# ---------------------------------------------------------------- conversations
def add_message(session_id: str, role: str, content: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO conversations (session_id, role, content, created_at) "
            "VALUES (?, ?, ?, ?)",
            (session_id, role, content, _now()),
        )


def get_history(session_id: str = "default", limit: int = 40):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT role, content FROM conversations WHERE session_id=? "
            "ORDER BY id DESC LIMIT ?",
            (session_id, limit),
        ).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


def clear_history(session_id: str = "default"):
    with get_conn() as conn:
        conn.execute("DELETE FROM conversations WHERE session_id=?", (session_id,))


# ---------------------------------------------------------------------- memory
def set_memory(key: str, value):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO memory (key, value, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, "
            "updated_at=excluded.updated_at",
            (key, json.dumps(value), _now()),
        )


def get_memory(key: str, default=None):
    with get_conn() as conn:
        row = conn.execute("SELECT value FROM memory WHERE key=?", (key,)).fetchone()
    return json.loads(row["value"]) if row else default


def all_memory():
    with get_conn() as conn:
        rows = conn.execute("SELECT key, value, updated_at FROM memory").fetchall()
    return [{"key": r["key"], "value": json.loads(r["value"]), "updated_at": r["updated_at"]} for r in rows]


def delete_memory(key: str):
    with get_conn() as conn:
        conn.execute("DELETE FROM memory WHERE key=?", (key,))


# ----------------------------------------------------------------------- tasks
def create_task(name, schedule_type, schedule_value, prompt, enabled=True):
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO tasks (name, schedule_type, schedule_value, prompt, "
            "enabled, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (name, schedule_type, schedule_value, prompt, int(enabled), _now()),
        )
        return cur.lastrowid


def list_tasks():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM tasks ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]


def get_task(task_id: int):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    return dict(row) if row else None


def update_task_run(task_id: int, result: str):
    with get_conn() as conn:
        conn.execute(
            "UPDATE tasks SET last_run=?, last_result=? WHERE id=?",
            (_now(), result, task_id),
        )


def set_task_enabled(task_id: int, enabled: bool):
    with get_conn() as conn:
        conn.execute("UPDATE tasks SET enabled=? WHERE id=?", (int(enabled), task_id))


def delete_task(task_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM tasks WHERE id=?", (task_id,))


# ------------------------------------------------------------------------ logs
def add_log(level: str, source: str, message: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO logs (level, source, message, created_at) VALUES (?, ?, ?, ?)",
            (level, source, message, _now()),
        )


def get_logs(limit: int = 200):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(r) for r in reversed(rows)]
