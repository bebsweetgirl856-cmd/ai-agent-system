const API = "";

// Wraps fetch: bounces to /login the moment a session expires/is invalid.
async function apiFetch(url, options = {}) {
  const res = await fetch(url, options);
  if (res.status === 401) {
    window.location.href = "/login";
    throw new Error("Not authenticated");
  }
  return res;
}

document.getElementById("btn-logout")?.addEventListener("click", async () => {
  await fetch(`${API}/api/logout`, { method: "POST" });
  window.location.href = "/login";
});

// ------------------------------------------------------------------ tabs
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
  });
});

// ---------------------------------------------------------------- status
async function refreshStatus() {
  try {
    const res = await apiFetch(`${API}/api/status`);
    const data = await res.json();
    const dot = document.getElementById("status-dot");
    const text = document.getElementById("status-text");
    if (data.agent_status === "running") {
      dot.className = "dot dot-running";
      text.textContent = `Running (${data.model})`;
    } else {
      dot.className = "dot dot-stopped";
      text.textContent = "Stopped";
    }
  } catch (e) {
    document.getElementById("status-text").textContent = "Disconnected from backend";
  }
}
setInterval(refreshStatus, 4000);
refreshStatus();

document.getElementById("btn-start").onclick = async () => {
  await apiFetch(`${API}/api/agent/start`, { method: "POST" });
  refreshStatus();
};
document.getElementById("btn-stop").onclick = async () => {
  await apiFetch(`${API}/api/agent/stop`, { method: "POST" });
  refreshStatus();
};
document.getElementById("btn-restart").onclick = async () => {
  await apiFetch(`${API}/api/agent/restart`, { method: "POST" });
  refreshStatus();
};

// ------------------------------------------------------------------ chat
const chatWindow = document.getElementById("chat-window");
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");

function appendMessage(role, content) {
  const div = document.createElement("div");
  div.className = `msg msg-${role}`;
  div.innerHTML = `<div class="msg-role">${role}</div>${escapeHtml(content)}`;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.innerText = str;
  return d.innerHTML;
}

async function loadHistory() {
  const res = await apiFetch(`${API}/api/history`);
  const history = await res.json();
  chatWindow.innerHTML = "";
  history.forEach(m => appendMessage(m.role, m.content));
}
loadHistory();

chatForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const message = chatInput.value.trim();
  if (!message) return;
  appendMessage("user", message);
  chatInput.value = "";
  const thinkingDiv = document.createElement("div");
  thinkingDiv.className = "msg msg-assistant";
  thinkingDiv.innerHTML = `<div class="msg-role">assistant</div>...thinking...`;
  chatWindow.appendChild(thinkingDiv);
  chatWindow.scrollTop = chatWindow.scrollHeight;

  try {
    const res = await apiFetch(`${API}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const data = await res.json();
    thinkingDiv.innerHTML = `<div class="msg-role">assistant</div>${escapeHtml(data.reply)}`;
  } catch (err) {
    thinkingDiv.innerHTML = `<div class="msg-role">assistant</div>ERROR: could not reach backend.`;
  }
});

document.getElementById("btn-clear").onclick = async () => {
  await apiFetch(`${API}/api/history/clear`, { method: "POST" });
  chatWindow.innerHTML = "";
};

// ----------------------------------------------------------------- tasks
async function loadTasks() {
  const res = await apiFetch(`${API}/api/tasks`);
  const tasks = await res.json();
  const list = document.getElementById("task-list");
  list.innerHTML = "";
  tasks.forEach(t => {
    const card = document.createElement("div");
    card.className = "task-card";
    card.innerHTML = `
      <div class="task-card-head">
        <div class="task-card-title">${escapeHtml(t.name)} ${t.enabled ? "" : "(disabled)"}</div>
        <div class="task-card-actions">
          <button class="btn btn-gray" data-toggle="${t.id}" data-enabled="${t.enabled}">${t.enabled ? "Disable" : "Enable"}</button>
          <button class="btn btn-red" data-delete="${t.id}">Delete</button>
        </div>
      </div>
      <div class="task-card-meta">
        Schedule: ${t.schedule_type} = ${escapeHtml(t.schedule_value)} &nbsp;|&nbsp;
        Last run: ${t.last_run || "never"}
      </div>
      <div class="task-card-meta">Prompt: ${escapeHtml(t.prompt)}</div>
    `;
    list.appendChild(card);
  });

  list.querySelectorAll("[data-toggle]").forEach(btn => {
    btn.onclick = async () => {
      const id = btn.dataset.toggle;
      const enabled = btn.dataset.enabled === "true" ? false : true;
      await apiFetch(`${API}/api/tasks/${id}/toggle?enabled=${enabled}`, { method: "POST" });
      loadTasks();
    };
  });
  list.querySelectorAll("[data-delete]").forEach(btn => {
    btn.onclick = async () => {
      await apiFetch(`${API}/api/tasks/${btn.dataset.delete}`, { method: "DELETE" });
      loadTasks();
    };
  });
}
loadTasks();
setInterval(loadTasks, 10000);

document.getElementById("task-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = {
    name: document.getElementById("task-name").value,
    schedule_type: document.getElementById("task-schedule-type").value,
    schedule_value: document.getElementById("task-schedule-value").value,
    prompt: document.getElementById("task-prompt").value,
    enabled: true,
  };
  await apiFetch(`${API}/api/tasks`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  e.target.reset();
  loadTasks();
});

// ------------------------------------------------------------------ tools
async function loadTools() {
  const res = await apiFetch(`${API}/api/tools`);
  const tools = await res.json();
  const list = document.getElementById("tool-list");
  list.innerHTML = "";
  tools.forEach(t => {
    const card = document.createElement("div");
    card.className = "tool-card";
    card.innerHTML = `<div class="tool-name">${escapeHtml(t.name)}</div><div class="tool-desc">${escapeHtml(t.description)}</div>`;
    list.appendChild(card);
  });
}
loadTools();

// ------------------------------------------------------------------- logs
const logWindow = document.getElementById("log-window");

async function loadLogHistory() {
  const res = await apiFetch(`${API}/api/logs?limit=200`);
  const logs = await res.json();
  logWindow.innerHTML = "";
  logs.forEach(renderLog);
}

function renderLog(entry) {
  const div = document.createElement("div");
  div.className = "log-line";
  const time = new Date(entry.created_at).toLocaleTimeString();
  div.innerHTML = `<span class="log-time">${time}</span><span class="log-${entry.level}">[${entry.level}] [${entry.source}] ${escapeHtml(entry.message)}</span>`;
  logWindow.appendChild(div);
  logWindow.scrollTop = logWindow.scrollHeight;
}

function connectLogSocket() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws/logs`);
  ws.onmessage = (event) => {
    const payload = JSON.parse(event.data);
    renderLog(payload);
  };
  ws.onclose = (event) => {
    if (event.code === 4401) {
      window.location.href = "/login";
      return;
    }
    setTimeout(connectLogSocket, 3000); // auto-reconnect
  };
}

loadLogHistory();
connectLogSocket();
