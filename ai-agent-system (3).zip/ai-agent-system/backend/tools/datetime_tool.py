from datetime import datetime
from tools.base import tool


@tool(
    name="get_current_datetime",
    description="Get the current date and time on the host PC. Use this whenever "
                "you need to know 'now', today's date, or the current time.",
    input_schema={"type": "object", "properties": {}, "required": []},
)
def get_current_datetime():
    return datetime.now().strftime("%A, %Y-%m-%d %H:%M:%S")
