import requests
from tools.base import tool


@tool(
    name="http_get",
    description="Fetch the raw text content of a public URL via HTTP GET. "
                "Useful for checking a webpage, an API endpoint, or a status "
                "page. Returns up to 4000 characters of the response body.",
    input_schema={
        "type": "object",
        "properties": {"url": {"type": "string", "description": "Full URL including https://"}},
        "required": ["url"],
    },
)
def http_get(url: str):
    try:
        resp = requests.get(url, timeout=15, headers={"User-Agent": "Local-AI-Agent/1.0"})
        text = resp.text[:4000]
        return f"Status: {resp.status_code}\n\n{text}"
    except Exception as e:
        return f"ERROR fetching URL: {e}"
