"""
Importing this package registers every tool module below into the tool
registry (tools/base.py). To add a new tool: create the file, then add one
import line here.
"""
from . import datetime_tool     # noqa: F401
from . import calculator_tool   # noqa: F401
from . import file_tool         # noqa: F401
from . import http_request_tool # noqa: F401
from . import memory_tool       # noqa: F401

from .base import get_tool_definitions, get_tool_names, execute_tool  # noqa: F401
