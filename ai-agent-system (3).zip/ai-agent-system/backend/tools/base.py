"""
Tool registry.

TO ADD A NEW TOOL LATER:
1. Create a new file in this `tools/` folder, e.g. `tools/my_tool.py`.
2. Decorate a function with @tool(name=..., description=..., input_schema=...)
3. Import it in `tools/__init__.py` (one line).
That's it - it will automatically show up for Claude to call.
"""
from typing import Callable, Dict, Any

_REGISTRY: Dict[str, Dict[str, Any]] = {}


def tool(name: str, description: str, input_schema: dict):
    """Decorator that registers a function as a Claude-callable tool.

    input_schema must be a valid JSON Schema object, e.g.:
        {
          "type": "object",
          "properties": {"city": {"type": "string"}},
          "required": ["city"]
        }
    """
    def decorator(func: Callable):
        _REGISTRY[name] = {
            "name": name,
            "description": description,
            "input_schema": input_schema,
            "func": func,
        }
        return func
    return decorator


def get_tool_definitions() -> list:
    """Returns the list of tool schemas in the format the Anthropic API expects."""
    return [
        {
            "name": t["name"],
            "description": t["description"],
            "input_schema": t["input_schema"],
        }
        for t in _REGISTRY.values()
    ]


def get_tool_names() -> list:
    return list(_REGISTRY.keys())


def execute_tool(name: str, tool_input: dict) -> str:
    """Runs the tool and always returns a string (Claude tool_result content)."""
    if name not in _REGISTRY:
        return f"ERROR: unknown tool '{name}'"
    try:
        result = _REGISTRY[name]["func"](**tool_input)
        return result if isinstance(result, str) else str(result)
    except Exception as e:
        return f"ERROR running tool '{name}': {e}"
