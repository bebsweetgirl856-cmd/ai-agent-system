import database as db
from tools.base import tool


@tool(
    name="remember",
    description="Save a fact to long-term memory (persists across restarts). "
                "Use a short, descriptive key, e.g. 'user_timezone' or "
                "'project_x_deadline'.",
    input_schema={
        "type": "object",
        "properties": {
            "key": {"type": "string"},
            "value": {"type": "string"},
        },
        "required": ["key", "value"],
    },
)
def remember(key: str, value: str):
    db.set_memory(key, value)
    return f"Remembered '{key}'."


@tool(
    name="recall",
    description="Recall a previously saved fact from long-term memory by key. "
                "If you don't know the exact key, use list_memory first.",
    input_schema={
        "type": "object",
        "properties": {"key": {"type": "string"}},
        "required": ["key"],
    },
)
def recall(key: str):
    val = db.get_memory(key)
    return str(val) if val is not None else f"No memory found for key '{key}'."


@tool(
    name="list_memory",
    description="List all keys (and values) currently stored in long-term memory.",
    input_schema={"type": "object", "properties": {}, "required": []},
)
def list_memory():
    items = db.all_memory()
    if not items:
        return "(memory is empty)"
    return "\n".join(f"{i['key']}: {i['value']}" for i in items)
