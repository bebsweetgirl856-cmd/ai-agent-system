"""
File tools. For safety these are sandboxed to the data/sandbox folder only -
the agent cannot read/write arbitrary paths on your PC. Change SANDBOX_DIR
in config.py if you want a different location.
"""
from pathlib import Path
from config import SANDBOX_DIR
from tools.base import tool


def _safe_path(filename: str) -> Path:
    p = (SANDBOX_DIR / filename).resolve()
    if not str(p).startswith(str(SANDBOX_DIR.resolve())):
        raise ValueError("Path escapes the sandbox directory - not allowed.")
    return p


@tool(
    name="write_file",
    description="Write text content to a file in the agent's local sandbox "
                "folder (data/sandbox). Overwrites if it already exists. Use "
                "for saving notes, generated content, or task output.",
    input_schema={
        "type": "object",
        "properties": {
            "filename": {"type": "string", "description": "Relative filename, e.g. 'notes.txt'"},
            "content": {"type": "string", "description": "Text content to write"},
        },
        "required": ["filename", "content"],
    },
)
def write_file(filename: str, content: str):
    path = _safe_path(filename)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return f"Wrote {len(content)} characters to {filename}"


@tool(
    name="read_file",
    description="Read the text content of a file from the agent's local "
                "sandbox folder (data/sandbox).",
    input_schema={
        "type": "object",
        "properties": {"filename": {"type": "string"}},
        "required": ["filename"],
    },
)
def read_file(filename: str):
    path = _safe_path(filename)
    if not path.exists():
        return f"ERROR: {filename} does not exist in the sandbox folder."
    return path.read_text(encoding="utf-8")


@tool(
    name="list_files",
    description="List all files currently in the agent's local sandbox folder.",
    input_schema={"type": "object", "properties": {}, "required": []},
)
def list_files():
    files = [str(p.relative_to(SANDBOX_DIR)) for p in SANDBOX_DIR.rglob("*") if p.is_file()]
    return "\n".join(files) if files else "(sandbox folder is empty)"
