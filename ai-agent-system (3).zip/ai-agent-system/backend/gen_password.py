"""
Run this once to generate the value for DASHBOARD_PASSWORD_HASH in your .env.

    python gen_password.py

It will prompt you for a password (hidden input) and print the bcrypt hash
to paste into .env. The plaintext password is never stored anywhere.
"""
import getpass
import bcrypt

if __name__ == "__main__":
    pw = getpass.getpass("Choose a dashboard password: ")
    pw2 = getpass.getpass("Confirm password: ")
    if pw != pw2:
        print("Passwords did not match. Try again.")
    elif len(pw) < 8:
        print("Please choose at least 8 characters.")
    else:
        hashed = bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()
        print("\nAdd this line to your .env file:\n")
        print(f"DASHBOARD_PASSWORD_HASH={hashed}")
