"""
Wraps APScheduler to run scheduled prompts through the agent. Task
definitions live in the `tasks` SQLite table so they survive restarts.
"""
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger

import database as db
import logger
from agent import controller, run_task_prompt

_scheduler = BackgroundScheduler()


def _job_id(task_id: int) -> str:
    return f"task_{task_id}"


def _run_task_job(task_id: int):
    if not controller.running:
        logger.info("scheduler", f"Skipping task {task_id} - agent is stopped.")
        return
    task = db.get_task(task_id)
    if not task or not task["enabled"]:
        return
    logger.info("scheduler", f"Running scheduled task '{task['name']}' (#{task_id})")
    try:
        result = run_task_prompt(task["prompt"])
        db.update_task_run(task_id, result)
        logger.info("scheduler", f"Task '{task['name']}' finished.")
    except Exception as e:
        logger.error("scheduler", f"Task '{task['name']}' failed: {e}")
        db.update_task_run(task_id, f"ERROR: {e}")


def _add_job(task: dict):
    if task["schedule_type"] == "interval":
        trigger = IntervalTrigger(minutes=int(task["schedule_value"]))
    elif task["schedule_type"] == "cron":
        trigger = CronTrigger.from_crontab(task["schedule_value"])
    else:
        logger.error("scheduler", f"Unknown schedule_type for task {task['id']}")
        return
    _scheduler.add_job(
        _run_task_job, trigger=trigger, args=[task["id"]],
        id=_job_id(task["id"]), replace_existing=True,
    )


def load_all_tasks():
    """(Re)loads every enabled task from the DB into the live scheduler."""
    for job in _scheduler.get_jobs():
        job.remove()
    for task in db.list_tasks():
        if task["enabled"]:
            _add_job(task)
    logger.info("scheduler", f"Loaded {len(_scheduler.get_jobs())} active scheduled task(s).")


def start():
    if not _scheduler.running:
        _scheduler.start()
    load_all_tasks()
    logger.info("scheduler", "Scheduler started.")


def stop():
    if _scheduler.running:
        _scheduler.shutdown(wait=False)
    logger.info("scheduler", "Scheduler stopped.")


def refresh():
    """Call after creating/editing/deleting a task."""
    load_all_tasks()
