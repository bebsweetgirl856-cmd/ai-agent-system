"""
Core agent logic: talks to the Claude API, gives it tools, loops on tool_use
until Claude produces a final text answer, and persists conversation history.
"""
import anthropic

import config
import database as db
import logger
import tools  # noqa: F401  (registers all tools)
from tools import get_tool_definitions, execute_tool

_client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)


class AgentController:
    """Tracks whether the agent is 'active' (accepting chat / running
    scheduled tasks) so the dashboard Start/Stop/Restart buttons have
    something real to control, independent of the web server process
    itself (which must keep running to serve the dashboard)."""

    def __init__(self):
        self.running = True

    def start(self):
        self.running = True
        logger.info("agent", "Agent started.")

    def stop(self):
        self.running = False
        logger.info("agent", "Agent stopped (scheduled tasks & chat paused).")

    def restart(self):
        self.stop()
        self.start()
        logger.info("agent", "Agent restarted.")

    def status(self):
        return "running" if self.running else "stopped"


controller = AgentController()


def run_conversation(user_message: str, session_id: str = "default") -> str:
    """Sends a user message to Claude, executes any tool calls it requests,
    loops until Claude gives a final answer, then persists + returns it."""
    if not controller.running:
        return "The agent is currently stopped. Start it from the dashboard first."

    db.add_message(session_id, "user", user_message)
    logger.info("chat", f"User: {user_message}")

    messages = db.get_history(session_id, limit=40)
    tool_defs = get_tool_definitions()

    final_text = ""
    for iteration in range(config.MAX_TOOL_ITERATIONS):
        try:
            response = _client.messages.create(
                model=config.CLAUDE_MODEL,
                max_tokens=config.MAX_TOKENS,
                system=config.AGENT_SYSTEM_PROMPT,
                tools=tool_defs,
                messages=messages,
            )
        except Exception as e:
            logger.error("agent", f"Claude API error: {e}")
            return f"ERROR calling Claude API: {e}"

        # Collect any text Claude produced this turn
        text_parts = [b.text for b in response.content if b.type == "text"]
        if text_parts:
            final_text = "\n".join(text_parts)

        if response.stop_reason != "tool_use":
            break

        # Claude wants to use one or more tools - execute them and reply
        assistant_content = [b.model_dump() for b in response.content]
        messages.append({"role": "assistant", "content": assistant_content})

        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                logger.info("tool", f"Calling '{block.name}' with input {block.input}")
                result = execute_tool(block.name, block.input)
                logger.info("tool", f"'{block.name}' result: {result[:300]}")
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result,
                })
        messages.append({"role": "user", "content": tool_results})
    else:
        logger.warn("agent", "Hit max tool iterations without a final answer.")
        if not final_text:
            final_text = "(Agent stopped after reaching the maximum number of tool steps.)"

    db.add_message(session_id, "assistant", final_text)
    logger.info("chat", f"Agent: {final_text[:300]}")
    return final_text


def run_task_prompt(prompt: str) -> str:
    """Used by the scheduler to run an autonomous/background prompt. Uses a
    separate session so scheduled-task chatter doesn't pollute your main
    dashboard conversation."""
    return run_conversation(prompt, session_id="scheduled_tasks")
