"""
Main entrypoint. Run with:
    uvicorn main:app --host 127.0.0.1 --port 8787
(or just `python main.py`, see bottom of file)
"""
import asyncio
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends, Request
from fastapi.responses import FileResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import config
import database as db
import logger
import scheduler
import auth
from agent import controller, run_conversation

app = FastAPI(title="Local AI Agent Dashboard")

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# ------------------------------------------------------------------- models
class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"


class LoginRequest(BaseModel):
    password: str


class TaskRequest(BaseModel):
    name: str
    schedule_type: str   # "interval" or "cron"
    schedule_value: str  # minutes (int as string) OR crontab string
    prompt: str
    enabled: bool = True


# --------------------------------------------------------------- lifecycle
@app.on_event("startup")
async def startup():
    db.init_db()
    logger.bind_loop(asyncio.get_event_loop())
    scheduler.start()
    logger.info("system", "Dashboard server started.")


@app.on_event("shutdown")
async def shutdown():
    scheduler.stop()
    logger.info("system", "Dashboard server shutting down.")


# ------------------------------------------------------------------- pages
@app.get("/")
async def index(request: Request):
    if not auth.is_authenticated(request):
        return RedirectResponse("/login")
    return FileResponse(str(STATIC_DIR / "index.html"))


@app.get("/login")
async def login_page(request: Request):
    if auth.is_authenticated(request):
        return RedirectResponse("/")
    return FileResponse(str(STATIC_DIR / "login.html"))


@app.post("/api/login")
async def login_submit(req: LoginRequest):
    if not config.AUTH_ENABLED:
        return {"ok": True}  # no password configured - nothing to check
    if not auth.verify_password(req.password):
        logger.warn("auth", "Failed login attempt.")
        raise HTTPException(status_code=401, detail="Incorrect password")
    resp = JSONResponse({"ok": True})
    resp.set_cookie(
        auth.SESSION_COOKIE,
        auth.create_session_cookie_value(),
        max_age=config.SESSION_MAX_AGE_SECONDS,
        httponly=True,
        samesite="lax",
        secure=config.DASHBOARD_HOST != "127.0.0.1",  # secure cookies once behind HTTPS
    )
    logger.info("auth", "Dashboard login successful.")
    return resp


@app.post("/api/logout")
async def logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.SESSION_COOKIE)
    return resp


# --------------------------------------------------------------------- chat
@app.post("/api/chat", dependencies=[Depends(auth.require_auth)])
async def chat(req: ChatRequest):
    loop = asyncio.get_event_loop()
    reply = await loop.run_in_executor(None, run_conversation, req.message, req.session_id)
    return {"reply": reply}


@app.get("/api/history", dependencies=[Depends(auth.require_auth)])
async def history(session_id: str = "default"):
    return db.get_history(session_id, limit=100)


@app.post("/api/history/clear", dependencies=[Depends(auth.require_auth)])
async def history_clear(session_id: str = "default"):
    db.clear_history(session_id)
    logger.info("chat", f"Conversation history cleared for session '{session_id}'.")
    return {"ok": True}


# ------------------------------------------------------------- agent control
@app.get("/api/status", dependencies=[Depends(auth.require_auth)])
async def status():
    return {
        "agent_status": controller.status(),
        "model": config.CLAUDE_MODEL,
        "scheduled_tasks": len(db.list_tasks()),
    }


@app.post("/api/agent/start", dependencies=[Depends(auth.require_auth)])
async def agent_start():
    controller.start()
    scheduler.start()
    return {"status": controller.status()}


@app.post("/api/agent/stop", dependencies=[Depends(auth.require_auth)])
async def agent_stop():
    controller.stop()
    return {"status": controller.status()}


@app.post("/api/agent/restart", dependencies=[Depends(auth.require_auth)])
async def agent_restart():
    controller.restart()
    scheduler.refresh()
    return {"status": controller.status()}


# -------------------------------------------------------------------- tools
@app.get("/api/tools", dependencies=[Depends(auth.require_auth)])
async def list_tools():
    from tools import get_tool_definitions
    return get_tool_definitions()


# -------------------------------------------------------------------- tasks
@app.get("/api/tasks", dependencies=[Depends(auth.require_auth)])
async def tasks_list():
    return db.list_tasks()


@app.post("/api/tasks", dependencies=[Depends(auth.require_auth)])
async def tasks_create(req: TaskRequest):
    task_id = db.create_task(
        req.name, req.schedule_type, req.schedule_value, req.prompt, req.enabled
    )
    scheduler.refresh()
    logger.info("scheduler", f"Created task '{req.name}' (#{task_id})")
    return {"id": task_id}


@app.post("/api/tasks/{task_id}/toggle", dependencies=[Depends(auth.require_auth)])
async def tasks_toggle(task_id: int, enabled: bool):
    db.set_task_enabled(task_id, enabled)
    scheduler.refresh()
    return {"ok": True}


@app.delete("/api/tasks/{task_id}", dependencies=[Depends(auth.require_auth)])
async def tasks_delete(task_id: int):
    db.delete_task(task_id)
    scheduler.refresh()
    logger.info("scheduler", f"Deleted task #{task_id}")
    return {"ok": True}


# --------------------------------------------------------------------- logs
@app.get("/api/logs", dependencies=[Depends(auth.require_auth)])
async def logs(limit: int = 200):
    return db.get_logs(limit)


@app.websocket("/ws/logs")
async def ws_logs(websocket: WebSocket):
    if config.AUTH_ENABLED:
        cookie = websocket.cookies.get(auth.SESSION_COOKIE, "")
        if not auth.verify_session_cookie(cookie):
            await websocket.close(code=4401)
            return
    await websocket.accept()
    queue = logger.subscribe()
    try:
        while True:
            payload = await queue.get()
            await websocket.send_json(payload)
    except WebSocketDisconnect:
        pass
    finally:
        logger.unsubscribe(queue)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=config.DASHBOARD_HOST, port=config.DASHBOARD_PORT, reload=False)
