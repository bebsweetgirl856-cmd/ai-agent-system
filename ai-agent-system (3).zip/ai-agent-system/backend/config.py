"""
Central configuration. Loads secrets from a .env file (never hardcode keys).
"""
import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent  # project root
load_dotenv(BASE_DIR / ".env")

# --- Secrets / model config -------------------------------------------------
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5").strip()
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "4096"))

# --- Dashboard / server config ----------------------------------------------
# 0.0.0.0 is required in the cloud/Docker deployment so the reverse proxy
# (Caddy) can reach the container. Stays 127.0.0.1 for local Windows use.
DASHBOARD_HOST = os.getenv("DASHBOARD_HOST", "127.0.0.1")
DASHBOARD_PORT = int(os.getenv("DASHBOARD_PORT", "8787"))

# --- Auth (required once the dashboard is reachable from the internet) ------
# Generate with: python backend/gen_password.py
DASHBOARD_PASSWORD_HASH = os.getenv("DASHBOARD_PASSWORD_HASH", "").strip()
# Random long string used to sign session cookies. Generate with:
#   python -c "import secrets; print(secrets.token_hex(32))"
SESSION_SECRET = os.getenv("SESSION_SECRET", "").strip()
SESSION_MAX_AGE_SECONDS = int(os.getenv("SESSION_MAX_AGE_SECONDS", str(60 * 60 * 24 * 30)))  # 30 days

# Deprecated in favor of DASHBOARD_PASSWORD_HASH but still honored for
# localhost-only setups that don't want to bother with login at all.
DASHBOARD_TOKEN = os.getenv("DASHBOARD_TOKEN", "").strip()

AUTH_ENABLED = bool(DASHBOARD_PASSWORD_HASH)
if AUTH_ENABLED and not SESSION_SECRET:
    print("[WARNING] DASHBOARD_PASSWORD_HASH is set but SESSION_SECRET is empty. "
          "Generate one (see .env.example) or logins won't persist safely.")

# --- Agent behaviour ---------------------------------------------------------
AGENT_SYSTEM_PROMPT = os.getenv(
    "AGENT_SYSTEM_PROMPT",
    "You are a helpful, capable personal AI agent running locally on the "
    "user's PC. You have tools available - use them whenever they help "
    "answer the request accurately. Be concise and direct.",
)
MAX_TOOL_ITERATIONS = int(os.getenv("MAX_TOOL_ITERATIONS", "8"))

# --- Paths --------------------------------------------------------------------
DATA_DIR = BASE_DIR / "data"
SANDBOX_DIR = DATA_DIR / "sandbox"   # the only folder the file tool may touch
DB_PATH = DATA_DIR / "agent.db"
LOG_FILE = DATA_DIR / "agent.log"

DATA_DIR.mkdir(exist_ok=True)
SANDBOX_DIR.mkdir(exist_ok=True, parents=True)

if not ANTHROPIC_API_KEY:
    print("[WARNING] ANTHROPIC_API_KEY is not set. Copy .env.example to .env "
          "and add your key before starting the agent.")
