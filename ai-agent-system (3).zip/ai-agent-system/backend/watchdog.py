"""
Watchdog process for 24/7 operation.

Runs the FastAPI/uvicorn server as a child process and automatically
restarts it if it crashes or exits unexpectedly, with exponential backoff
to avoid a crash-loop hammering your PC (or the Claude API).

This is the script you should point NSSM / Task Scheduler at for true
"run forever, recover from crashes" behaviour.
"""
import subprocess
import sys
import time
from pathlib import Path

import config
import logger
import database as db

BACKEND_DIR = Path(__file__).parent
MAX_BACKOFF = 300  # seconds


def main():
    db.init_db()
    backoff = 5
    logger.info("watchdog", "Watchdog started - agent will auto-restart on crash.")

    while True:
        logger.info("watchdog", "Launching agent server...")
        start_time = time.time()
        proc = subprocess.Popen(
            [
                sys.executable, "-m", "uvicorn", "main:app",
                "--host", config.DASHBOARD_HOST,
                "--port", str(config.DASHBOARD_PORT),
            ],
            cwd=str(BACKEND_DIR),
        )
        exit_code = proc.wait()
        uptime = time.time() - start_time

        if exit_code == 0:
            logger.info("watchdog", "Agent server exited cleanly. Watchdog exiting too.")
            break

        logger.error(
            "watchdog",
            f"Agent server crashed (exit code {exit_code}) after {uptime:.0f}s uptime.",
        )

        # Reset backoff if it had been running fine for a while
        if uptime > 60:
            backoff = 5
        else:
            backoff = min(backoff * 2, MAX_BACKOFF)

        logger.info("watchdog", f"Restarting in {backoff} seconds...")
        time.sleep(backoff)


if __name__ == "__main__":
    main()
