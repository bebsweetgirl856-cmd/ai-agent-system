"""
Simple pub/sub logger: every log line is written to SQLite AND pushed to any
connected WebSocket dashboard clients in real time.
"""
import asyncio
import json
from datetime import datetime, timezone
from typing import List

import database as db

_subscribers: List[asyncio.Queue] = []
_main_loop: asyncio.AbstractEventLoop | None = None


def bind_loop(loop: asyncio.AbstractEventLoop):
    """Call once from the FastAPI startup event so background threads can
    safely schedule broadcasts onto the main asyncio loop."""
    global _main_loop
    _main_loop = loop


def subscribe() -> asyncio.Queue:
    q: asyncio.Queue = asyncio.Queue()
    _subscribers.append(q)
    return q


def unsubscribe(q: asyncio.Queue):
    if q in _subscribers:
        _subscribers.remove(q)


def _broadcast(payload: dict):
    for q in list(_subscribers):
        try:
            q.put_nowait(payload)
        except Exception:
            pass


def log(level: str, source: str, message: str):
    """Thread-safe logging entry point. Safe to call from the scheduler
    thread, tool-execution threads, or the main async loop."""
    level = level.upper()
    print(f"[{level}] [{source}] {message}")
    db.add_log(level, source, message)
    payload = {
        "type": "log",
        "level": level,
        "source": source,
        "message": message,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    if _main_loop is not None:
        try:
            _main_loop.call_soon_threadsafe(_broadcast, payload)
        except RuntimeError:
            pass
    else:
        _broadcast(payload)


def info(source: str, message: str):
    log("INFO", source, message)


def warn(source: str, message: str):
    log("WARN", source, message)


def error(source: str, message: str):
    log("ERROR", source, message)
