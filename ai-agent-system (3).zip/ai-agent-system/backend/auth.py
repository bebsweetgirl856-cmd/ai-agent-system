"""
Minimal single-user auth for the dashboard: one shared password (bcrypt
hash stored in .env, never the plaintext), sessions are a signed,
tamper-proof cookie (itsdangerous) - no server-side session store needed.

This is intentionally simple: this app is meant for exactly one owner
(you). If you need multi-user accounts, that's a bigger change than this
file.
"""
import bcrypt
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from fastapi import Request, HTTPException

import config

SESSION_COOKIE = "agent_session"
_serializer = URLSafeTimedSerializer(config.SESSION_SECRET or "insecure-dev-secret")


def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode(), bcrypt.gensalt()).decode()


def verify_password(plain: str) -> bool:
    if not config.DASHBOARD_PASSWORD_HASH:
        return False
    try:
        return bcrypt.checkpw(plain.encode(), config.DASHBOARD_PASSWORD_HASH.encode())
    except Exception:
        return False


def create_session_cookie_value() -> str:
    return _serializer.dumps({"user": "owner"})


def verify_session_cookie(value: str) -> bool:
    if not value:
        return False
    try:
        _serializer.loads(value, max_age=config.SESSION_MAX_AGE_SECONDS)
        return True
    except (BadSignature, SignatureExpired):
        return False


def require_auth(request: Request):
    """FastAPI dependency: raises 401 unless auth is disabled (local-only
    mode with no password set) or a valid session cookie is present."""
    if not config.AUTH_ENABLED:
        return  # local/dev mode - no password configured
    cookie = request.cookies.get(SESSION_COOKIE, "")
    if not verify_session_cookie(cookie):
        raise HTTPException(status_code=401, detail="Not authenticated")


def is_authenticated(request: Request) -> bool:
    if not config.AUTH_ENABLED:
        return True
    return verify_session_cookie(request.cookies.get(SESSION_COOKIE, ""))
