# Deploying on Oracle Cloud Infrastructure (OCI) — Always Free tier

Oracle's "Always Free" tier is one of the more generous free options for
this kind of always-on personal dashboard, and unlike a lot of "free trial"
offers, the Always Free resources don't expire after a trial period. As with
the other guides, this covers the OCI-specific "get a server" steps -
once you have a public IP and can SSH in, jump to `README.md` →
**"Deploying to a cloud server"**, step 2 onward, for the Docker/Caddy part.

> **Note on which Oracle product this is:** if you were looking at Oracle's
> "Getting Started with Oracle Cloud Applications" documentation, that's a
> different product (Oracle's enterprise SaaS suite - ERP/HCM/CRM). What you
> want for hosting a Docker container is **Oracle Cloud Infrastructure
> (OCI)**, specifically OCI Compute - a normal virtual machine, which is
> what this guide covers.

## What's actually free (as of mid-2026 - verify at signup)

Oracle changed these limits in June 2026, so double-check current numbers
at [oracle.com/cloud/free](https://www.oracle.com/cloud/free/) before you
commit to a shape, but as of this writing, Always Free includes:
- **Ampere A1 (ARM) Compute**: 2 OCPUs + 12 GB RAM total (down from 4/24 -
  Oracle halved this in June 2026), usable as one VM or split across
  smaller ones
- **2x AMD Micro instances** (`VM.Standard.E2.1.Micro`) - tiny (1/8 OCPU,
  1GB RAM each), but enough for this dashboard if you don't need the ARM
  instance for anything else
- **200 GB block storage** total
- **10 TB/month outbound bandwidth**

For this project, either a single **AMD Micro** instance or a small slice
of the **ARM Ampere A1** works fine - the agent itself is lightweight (the
model inference happens on Anthropic's servers, not your VM).

## 1. Sign up

1. Go to [oracle.com/cloud/free](https://www.oracle.com/cloud/free/) and
   click **Start for Free**.
2. You'll need to verify your identity with a **credit card** - this is
   standard for OCI even for the free tier (fraud prevention), but you
   will not be charged as long as you stay within Always Free limits.
3. Choose your **Home Region** carefully - this **cannot be changed
   later** without creating a new account. Pick one geographically close
   to you (affects latency, and ARM capacity availability - see the note
   below).
4. Complete verification. Note that new accounts sometimes take a few
   minutes to a few hours to fully activate.

## 2. Create a Compute instance

1. In the OCI Console, go to **Menu → Compute → Instances → Create
   Instance**.
2. **Name**: anything, e.g. `ai-agent`.
3. **Image and shape**: click **Edit** next to the shape.
   - **Image**: change to **Ubuntu** (22.04 or newer) if not already
     selected - Oracle defaults to Oracle Linux, but Ubuntu matches the
     Docker instructions in `README.md` most directly.
   - **Shape**: click **Change Shape**:
     - For the ARM option: select **Ampere** → `VM.Standard.A1.Flex`, and
       set **1-2 OCPUs / 6-12 GB RAM** (whatever you have free capacity
       for - see the capacity note below).
     - For the simpler option: select **AMD** → `VM.Standard.E2.1.Micro`
       (always available, no capacity contention, but only 1GB RAM - fine
       for this project alone, tight if you run much else on the box).
4. **Add SSH keys**: choose **Generate a key pair for me**, then
   **Save Private Key** (and public key) to your computer - you'll need
   the private key to log in. Alternatively, upload your own public key
   if you already have one.
5. Leave networking/storage on defaults, then click **Create**.
6. Wait 1-3 minutes for the instance to reach **Running** state, then note
   its **Public IP address** from the instance details page.

### If you hit "Out of host capacity" (ARM shape only)

The free ARM (Ampere A1) shape is popular and some regions run out of
capacity. If this happens:
- Try a different **Availability Domain** within your region (the create
  form usually lets you pick).
- Try again in a few minutes/hours - capacity frees up as other users'
  instances are reclaimed for inactivity.
- Or just switch to the **AMD Micro** shape instead, which doesn't have
  this problem and is enough to run this dashboard.

## 3. Open the required ports - Oracle blocks inbound traffic TWICE

This is the step almost everyone misses on OCI: **traffic is blocked at
two separate layers**, and you must open it at both, or your agent will
be unreachable even though the VM is running fine.

### Layer 1: the cloud-level Security List
1. **OCI Console → Networking → Virtual Cloud Networks** → click your
   VCN → click the **Subnet** your instance is in → click the
   **Security List** attached to it (usually "Default Security List").
2. **Add Ingress Rules** for:
   - Source CIDR `0.0.0.0/0`, IP Protocol `TCP`, Destination Port `80`
   - Source CIDR `0.0.0.0/0`, IP Protocol `TCP`, Destination Port `443`
   - (Port 22/SSH is usually already open by default - verify it's there.)

### Layer 2: the OS firewall inside the VM
Oracle's Ubuntu images ship with `iptables`/`netfilter` rules that block
incoming traffic by default, separate from the cloud firewall above. SSH
in first (see step 4), then run:
```bash
sudo iptables -I INPUT 6 -m state --state NEW -p tcp --dport 80 -j ACCEPT
sudo iptables -I INPUT 6 -m state --state NEW -p tcp --dport 443 -j ACCEPT
sudo netfilter-persistent save
```
(If `netfilter-persistent` isn't installed: `sudo apt install iptables-persistent -y` first, then re-run the save command.)

Skipping either layer is the #1 reason a fresh OCI deployment looks "down" from outside even though `docker compose ps` shows everything healthy.

## 4. SSH into the instance

```bash
chmod 400 /path/to/your-private-key.pem
ssh -i /path/to/your-private-key.pem ubuntu@<your-instance-public-ip>
```
(Default username is `ubuntu` for Ubuntu images on OCI, not `root`.)

## 5. Point your domain at the instance

Same as any provider: add an **A record** for your domain (or subdomain,
e.g. `agent.yourdomain.com`) pointing at the instance's public IP, in
whatever DNS provider manages that domain. Verify with:
```bash
ping agent.yourdomain.com
```

## 6. Continue with the standard Docker deployment

From here, follow `README.md` → **"Deploying to a cloud server"**, starting
at step 2 ("Install Docker on the server"):

```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
# log out and back in

# from your own machine:
scp -i /path/to/your-private-key.pem -r ai-agent-system ubuntu@<ip>:~/ai-agent-system

cd ai-agent-system
cp .env.example .env
nano .env   # ANTHROPIC_API_KEY, DOMAIN, SESSION_SECRET, DASHBOARD_PASSWORD_HASH

docker compose up -d --build
```

Then open `https://agent.yourdomain.com` on your iPhone and log in.

## OCI-specific notes

- **Idle reclamation**: Oracle can reclaim Always Free compute instances
  that sit completely idle for an extended period (no CPU/memory/network
  activity). A 24/7 agent dashboard with scheduled tasks running and
  occasional chat use is exactly the kind of "legitimate" activity that
  avoids this - you shouldn't need to do anything extra.
- **ARM vs AMD**: if you picked the ARM (Ampere A1) shape, make sure any
  Docker images you build are ARM64-compatible. The `python:3.12-slim`
  base image used in this project's `Dockerfile` already supports ARM64
  natively, so no changes needed.
- **Free tier limits can change**: Oracle adjusted the ARM compute
  allocation mid-2026 without much notice. Always sanity-check current
  limits at [oracle.com/cloud/free](https://www.oracle.com/cloud/free/)
  if something looks different from this guide.
